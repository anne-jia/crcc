import customTranslate from './CustomTranslate'

export default {
    translate: ['value', customTranslate]
}