import Vue from 'vue'

const workflowEventBus = new Vue();

Vue.$workflowEventBus = workflowEventBus

function PropertiesEventHandlerProvider(eventBus) {
    eventBus.on('message-setting.openning', function(event) {
        workflowEventBus.$emit('message-setting.openning', event)
    })

    eventBus.on('sys-participant.opening', function(event) {
        workflowEventBus.$emit('sys-participant.openning', event)
    })


    workflowEventBus.$on('message-setting.saved', function(event) {
        eventBus.fire('message-setting.saved', event)
    })

    workflowEventBus.$on('participant.saved', function(event) {
        eventBus.fire('participant.saved', event)
    })

}

PropertiesEventHandlerProvider.$inject = [ 'eventBus' ]

export default PropertiesEventHandlerProvider