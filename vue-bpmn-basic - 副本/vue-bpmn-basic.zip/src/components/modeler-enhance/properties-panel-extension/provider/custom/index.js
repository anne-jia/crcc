import CustomPropertiesProvider from './CustomPropertiesProvider';

export default {
  __init__: [ 'propertiesProvider' ],
  propertiesProvider: [ 'type', CustomPropertiesProvider ]
};
