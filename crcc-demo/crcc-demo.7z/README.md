### 需要卸载得依赖
1.nprogress

### 需要删除得文件

1.src/components文件下 ：Hamburger，Breadcrumb，Headers，HeaderSearch，Pagination，RightPanel，SvgIcon，templateUI

2.src/permission.js



### 需要替换的同命文件夹/同名文件

1. src/layout
2.src/icons/index.js

