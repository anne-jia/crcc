
import {  constantRoutes,asyncRoutes,commitRouter} from '@crcc/crcc_commmon_ui'
import { getUserMenus, hasPermission } from '@/api/permission'

/* Layout */
import Layout from '@/layout'
import APP from '@/App'
const files = require.context('@/views', true, /\.vue$/)
// var pages = []
// files.keys().forEach(key => {
//   pages.push(key.replace(/(\.\/|\.vue)/g, ''))
// })

const _import = require('@/router/_import_' + process.env.NODE_ENV) // 获取组件的方法
import list from './router.json'
const state = {
  // 所有的路由
  routes: [],
  // 添加路由
  addRoutes: [],
  menus: [],
  // 是否有权限
  hasPermission
}

const mutations = {
   // 设置路由
   SET_ADDROUTES: (state, routes) => {
    state.addRoutes = routes
  },
  //添加路由
  SET_ROUTES: (state, routes) => {
    state.routes = routes
  },
  // 设置菜单
  SET_MENUS: (state, menus) => {
    state.menus = menus
  },
  SET_HASPERMISSION: (state, hasPermission) => {
    state.hasPermission = hasPermission
  }
}

const actions = {
  generateRoutes({ commit }) {
    return new Promise((resolve, reject) => {
      // 获取后端菜单
      getUserMenus()
        .then(response => {
          let getRouter = commitRouter(commit, Layout, APP, _import, files, response, constantRoutes);
          
          resolve(getRouter)
        })
        .catch(error => {
          const routerList = list.list
         let getRouter = commitRouter(commit, Layout, APP, _import, files,routerList, constantRoutes);
          resolve(getRouter)
          // reject(error);
        })
    })
  },


  // 菜单数据 根据接口获取
  generateMenus({ commit }, menu) {
    const menus = [...menu]
    const accessedMenus = filterMenus(menus)
    commit('SET_MENUS', accessedMenus)
    // resolve(routers)
  },
  // 是否有权限
  getHasPermission({ commit }) {
    return new Promise((resolve, reject) => {
      // 是否有授权主体权限
      hasPermission()
        .then(response => {
          if (response !== undefined) {
            commit('SET_HASPERMISSION', response)
            resolve(response)
          }
        })
        .catch(error => {
          reject(error)
        })
    })
  }
}
// /**
//  * 
//  * @param {*} commit 
//  * @param {*Array} constantRoutes 固定路由
//  * @param {*Array} asyncRoutes 异步路由
//  * @param {*实例对象} Layout(布局组件)
//  * @param {*实例对象} APP(布局组件)
//  * @param {*function} component(组件实例)
//  * 
//  */
// function commitRouter(commit, Layout, APP, components, asyncRoutes, constantRoutes) {
//   const inIframe = process.env.VUE_APP_IFRAME_STYLE === 'in-iframe'
//   let getRouter = [];
//   if (asyncRoutes.length) {
//       getRouter = filterAsyncRouter([...asyncRoutes],Layout,APP,components,inIframe)
//       getRouter = getRouter.concat(errorRouter)
//     } else {
//       getRouter = errorRouter
//     }
//     commit('SET_ROUTES', getRouter)
//     const accessedMenus = filterMenus([...asyncRoutes])
//     commit('SET_MENUS', accessedMenus)
//   return getRouter;
// };



// function filterAsyncRouter(asyncRouterMap, Layout, APP, components, inIframe) {
//   // 遍历后台传来的路由字符串，转换为组件对象
//   const accessedRouters = asyncRouterMap.filter(route => {
//     if (!route.component) {
//       return
//     } else {
//       if (route.component) {
//         if (route.component === 'Layout') {
//           // Layout组件特殊处理
//           route.component = inIframe ? APP : Layout
//         } else {
//           const index = pages.findIndex(item => {
//             return item === route.component
//           })
//           if (index === -1) {
//             route.component = components('error-page/404')
//           } else {
//             route.component = components(route.component)
//           }
//         }
//       }
//       if (route.children && route.children.length) {
//         route.children = filterAsyncRouter(route.children, Layout, APP, components, inIframe)
//       }
//       return true
//     }
//   })
//   return accessedRouters
// }

// /**
//  * 过滤菜单数据：移除同路由没匹配上的菜单
//  * @param {菜单接口获取的原始数据（树形结构）}} menus
//  * 菜单过来，左侧的菜单栏不需要显示的部分
//  */
// function filterMenus(menus) {
//   if (menus) {
//     for (var i = menus.length - 1; i >= 0; i--) {
//       const children = menus[i].items
//       if (children && children.length > 0) {
//         filterMenus(children)
//       } else {
//         if (menus[i].isHomePage) {
//           menus.splice(i, 1)
//         }
//       }
//     }
//   }
//   return menus
// }


export default {
  namespaced: true,
  state,
  mutations,
  actions
}
