<template>
  <AuthSubjectTableWithOrgTree />
</template>