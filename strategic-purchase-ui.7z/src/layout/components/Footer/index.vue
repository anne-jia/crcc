<template>
    <div class="footer">
        <span>中国铁建股份有限公司&nbsp;&nbsp;版权所有&nbsp;&nbsp;建设监管:&nbsp;&nbsp;中国铁建股份有限公司</span>
         <span>技术维护：&nbsp;&nbsp;中铁建网络信息科技有限公司</span>
    </div>
</template>

<script>
export default {
    
}
</script>

<style lang="scss" scoped>
.footer{
    display: flex;
    flex-direction: column;
    justify-content: center;
    align-items: center;
    color:rgba(170, 168, 168,.5);
    font-size: 10px;
}
</style>