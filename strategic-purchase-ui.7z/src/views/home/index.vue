<template>
 <div>
   home
</div>
</template>

<script>
export default {

  name: "Home",


};
</script>
<style lang="scss" scoped>
  .el-main{
    height: calc(100vh - 48px);
    background: #ebf2f6;
  }
</style>