<!--  detail-table-->
<template>
    <div class='detail-box'>
        <div class="btn-group">
            <el-button plain @click="addDetail"> 新增 </el-button>
            <el-button plain> 删除 </el-button>
        </div>
        <div class="table-box">
            <el-table :data="value" border   stripe highlight-current-row  :row-class-name="setEditClassName" @current-change="editSuppliesDetail">
                <el-table-column :index="tableIndex" type="index" label="序号" width="50" align="center" show-overflow-tooltip />
                <el-table-column prop="sortPath" label="物料分类编码" header-align="center" align="left" show-overflow-tooltip />
                <el-table-column prop="sortName" label="物料分类名称" header-align="center" align="left" show-overflow-tooltip />
                <el-table-column prop="unitName" label="计量单位" header-align="center" align="left" show-overflow-tooltip />
                <el-table-column prop="needNumber" label="数量" header-align="center" align="left" show-overflow-tooltip>
                    <template slot-scope="{$index,row}">
                        <span v-if="row.isEdit ">
                            <el-input :key="$index"  v-model="row.needNumber" placeholder="数量"  />
                        </span>
                        <span v-else>{{ row.needNumber }}</span>
                    </template>
                </el-table-column>
                <el-table-column prop="unitPrice" label="含税单价" header-align="center" align="left" show-overflow-tooltip>
                    <template slot-scope="{$index,row}">
                        <span v-if="row.isEdit ">
                            <el-input :key="$index" v-model="row.unitPrice" placeholder="含税单价"  />
                        </span>
                        <span v-else>{{ row.unitPrice }}</span>
                    </template>
                </el-table-column>
                <el-table-column prop="unUnitPrice" label="不含税单价" header-align="center" align="left" show-overflow-tooltip>
                    <template slot-scope="{$index,row}">
                        <span v-if="row.isEdit ">
                            <el-input :key="$index" v-model="row.unUnitPrice" placeholder="不含税单价"  />
                        </span>
                        <span v-else>{{ row.unUnitPrice }}</span>
                    </template>
                </el-table-column>
                <el-table-column prop="taxRate" label="税率" header-align="center" align="left" show-overflow-tooltip>
                    <template slot-scope="{$index,row}">
                        <span v-if="row.isEdit ">
                            <el-input :key="$index" v-model="row.taxRate" placeholder="税率"  />
                        </span>
                        <span v-else>{{ row.taxRate }}</span>
                    </template></el-table-column>
                <el-table-column prop="unitMoeny" label="含税金额" header-align="center" align="left" show-overflow-tooltip>
                    <template slot-scope="{$index,row}">
                        <span v-if="row.isEdit ">
                            <el-input :key="$index" v-model="row.unitMoeny" placeholder="含税金额"  />
                        </span>
                        <span v-else>{{ row.unitMoeny }}</span>
                    </template></el-table-column>
                <el-table-column prop="unUnitMoeny" label="不含税金额" header-align="center" align="left" show-overflow-tooltip>
                    <template slot-scope="{$index,row}">
                        <span v-if="row.isEdit ">
                            <el-input :key="$index" v-model="row.unUnitMoeny" placeholder="不含税金额"  />
                        </span>
                        <span v-else>{{ row.unUnitMoeny }}</span>
                    </template>
                </el-table-column>
                <el-table-column prop="manuFacturers" label="制造商" header-align="center" align="left" show-overflow-tooltip >
                   <template slot-scope="{$index,row}">
                        <span v-if="row.isEdit ">
                            <el-input :key="$index" v-model="row.manuFacturers" placeholder="制造商"  />
                        </span>
                        <span v-else>{{ row.manuFacturers }}</span>
                    </template>
                </el-table-column>
                <el-table-column prop="factoryModel" label="厂家型号" header-align="center" align="left" show-overflow-tooltip >
                       <template slot-scope="{$index,row}">
                        <span v-if="row.isEdit ">
                            <el-input :key="$index" v-model="row.factoryModel" placeholder="厂家型号"  />
                        </span>
                        <span v-else>{{ row.factoryModel }}</span>
                    </template>
                    </el-table-column>
                <el-table-column prop="note" label="备注" header-align="center" align="left" show-overflow-tooltip >
                       <template slot-scope="{$index,row}">
                        <span v-if="row.isEdit ">
                            <el-input :key="$index" v-model="row.note" placeholder="备注"  />
                        </span>
                        <span v-else>{{ row.note }}</span>
                    </template>
                </el-table-column>
            </el-table>
        </div>
        
        <mat-code-help ref="matCodeHelp" :currentOrgId="currentOrgId" @saveCheckedValue="checkedSupplies"></mat-code-help>
    </div>
</template>

<script>
//物料列表
import matCodeHelp from '@/components/MatCodeHelp/MatCodeHelp.vue';
export default {
    model: {
         prop:  'value' ,
         event:  'change'
     },
    props: {
        value: {
            type: Array,
            default: function () {
                return []
            }
        },
        currentOrgId:String,
    },
    components: {
        matCodeHelp
    },
  
    data() {
        return {
            //框架信息协议明细
            DetailsFormData: {
                materialName: "",
                materialCode: "",
                spec: "",
                unitName: "",
                sortName: "",
                sortPath: "",
                needNumber: "",
                unitPrice: "",
                unUnitPrice: "",
                taxRate: "",
                unitMoeny: "",
                manuFacturers: "",
                factoryModel: "",
                note: "",
            },
        }
    },
    computed: {
 
    },
    methods: {
        addDetail() {
            this.$refs.matCodeHelp.dialogVisible =true;
        },
        // 获取选中的物料
        checkedSupplies(data){
            if(data.length>0){
             let newData = data.concat(this.value)
             this.$emit('change', newData);
            }
        },
        editSuppliesDetail(currentRow, oldCurrentRow){
            if(oldCurrentRow){
                oldCurrentRow.isEdit =false
            }
            currentRow.isEdit =true;
        },
        setEditClassName(val){
            return val.row.isEdit?'edit-row':''
        },
          // 序号
        tableIndex(index) {
            return index+1;
        },
        
    },
    mounted() {

    },
}
</script>

<style lang="scss" scoped>
$borderColor: #dcdfe6;

.detail-box {
    height: 100%;
    width: 100%;

    .btn-group {
        padding: 0px 8px 8px 8px;
        border-bottom: 1px solid $borderColor;

        .el-tooltip.el-button {
            padding: 0px 8px;
        }
    }

  ::v-deep .table-box {
        padding: 8px;
        box-sizing: border-box;
        .el-table .el-table__row.edit-row .cell{
            height: 28px;
            line-height: 28px;
        }
    }
}
</style>
