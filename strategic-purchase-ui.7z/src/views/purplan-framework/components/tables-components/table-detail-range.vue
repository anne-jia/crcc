<!--  table-detail-rangale-->
<template>
    <div class='range-box'>
        <div class="btn-group">
            <el-button plain :disabled="switchCover" @click="addDetail">
                新增
            </el-button>
            <el-button plain> 删除 </el-button>
            <el-tooltip effect="dark" content="应用覆盖" placement="bottom">
                <el-button plain>
                    <el-switch v-model="switchCover" @change="changeSwitch">/>
                    </el-switch>
                </el-button>
            </el-tooltip>
        </div>
        <div class="table-box">
            <el-table :data="value" border>
                <el-table-column type="index" label="序号" width="50" align="center" show-overflow-tooltip />
                <!-- 覆盖所有采购单位 -->
                <el-table-column prop="manageOrgName" label="组织编号" header-align="center" align="left" show-overflow-tooltip />
                <el-table-column prop="sortPath" label="组织名称" header-align="center" align="left" show-overflow-tooltip />
                <!-- <el-table-column prop="sortName" label="备注" header-align="center" align="left" show-overflow-tooltip /> -->
            </el-table>
        </div>
        <range-help ref="rangaleHelp" @getRowRangeData="onecoverageData" :rootNode="currentOrgInfo"/>
    </div>
</template>

<script>
import RangeHelp from "@/components/Rangehelp/RangeHelp";
  
export default {
    props: {
        value: {
            type: Array,
            default: function () {
                return []
            }
        },
         currentOrgInfo: {
            type: Array,
            default: function () {
                return {
                code: "",
                name: "",
                fullName: "",
                layer: 1,
                sortOrder: 2,
                isLeaf: 0,
                hrCode: "",
                parentId: "",
             }
            }
        },
    },
      model: {
         prop:  'value' ,
         event:  'change'
     },
    components: {
        RangeHelp,
    },
    data() {
        return {
            switchCover: false,
            //应用覆盖范围
            rangesFormData: {
                manageOrgName: "",
                sortPath: "",
                sortName: "",
            },

        }
    },
    computed: {

    },
    methods: {
        addDetail() {

        },
        changeSwitch() {

        },
        // 选择一条覆盖范围数据
        onecoverageData(data) {
            console.log(data);
            this.purchaseData.purchaseRanges = data;
        },
 
      getsupplerData(data) {},
       getMaterial(data) {},
    },
    mounted() {

    },
}
</script>

<style lang="scss" scoped>
$borderColor: #dcdfe6;

.range-box {
    height: 100%;
    width: 100%;

    .btn-group {
        padding: 0px 8px 8px 8px;
        border-bottom: 1px solid $borderColor;

        .el-tooltip.el-button {
            padding: 0px 8px;
        }
    }

    .table-box {
        padding: 8px;
        box-sizing: border-box;
    }
}
</style>
