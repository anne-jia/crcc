<template>
  <SystemLogTableWithTree :orgDeepType="orgDeepType"></SystemLogTableWithTree>
</template>

<script>
export default {
  data() {
    return {
      orgDeepType: 2
    };
  }
};
</script>

<style lang="scss" scoped>
</style>
